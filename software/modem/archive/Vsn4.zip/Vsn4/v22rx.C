/* Modem for MIPS   AJF	  December 1995
   V.22 receive routines
*/

#include <signal.h>
#include <fishaudio.h>
#include <coro.h>
#include "complex.h"
#include "modem.h"
#include "v22.h"

#define FASTSIG	    0x33333333		/* "S1" signal, means 2400 bps      */

static uint phinc, scrambler[2];
static coroutine *bitco = NULL;

static void init(vmode);
static int gasync(), gsync(), gbit();

global rxhandler v22_rxhandler = { init, gasync, gsync, gbit };

global vmode v22_mode;		/* used by bitloop */
global uint v22_conrate;	/* used by bitloop */


static void init(vmode mode)
  { v22_mode = mode;
    unless (v22_mode == V22o || v22_mode == V22a) giveup("Bug! bad mode %d in V.22 rx init", v22_mode);
    Audio -> idiscard();    /* empty Rx ring buffer */
    scrambler[0] = scrambler[1] = 0;
    v22_conrate = bps_1200;	/* handshaking done at 1200 bps */
    if (bitco != NULL) delete bitco;
    bitco = new coroutine(v22_bitloop);
    /* look for 2 sec of scrambled 1 (NB spec says 270 ms), or 16 repeated "0011"; 20 sec timeout */
    int n = 0, t = 0;
    enum { looking, fail, c1200, c2400 } state = looking;
    while (state == looking)
      { if (gbit() == 1) n++; else n = 0;
	if ((bitrates & bps_1200) && (n >= 2400)) state = c1200;
	if ((bitrates & bps_2400) && (scrambler[0] == FASTSIG) && (scrambler[1] == FASTSIG)) state = c2400;
	if (t++ >= 24000) state = fail;
      }
    switch (state)
      { case fail:
	    v22_conrate = 0;		/* will eventually cause EOF to be returned */
	    break;

	case c1200:
	    kill(getppid(), sig_1200);	/* tell Tx we're working at 1200 bps */
	    break;

	case c2400:
	    kill(getppid(), sig_2400);	/* tell Tx we're working at 2400 bps */
	    v22_conrate = bps_2400;
	    break;
      }
    unless (v22_conrate == 0)
      { /* look for 5 secs of 1s, 30 sec timeout (equalization is slow!) */
	int mn = (v22_conrate == bps_2400) ? 12000 : 6000;  /* 5 secs  */
	int mt = (v22_conrate == bps_2400) ? 72000 : 36000; /* 30 secs */
	int n = 0, t = 0;
	until (n >= mn || t >= mt)
	  { if (gbit() == 1) n++; else n = 0;
	    t++;
	  }
	if (n >= mn) infomsg("Equalized");
	else v22_conrate = 0;	/* will eventually cause EOF to be returned */
      }
  }

static int gasync()
  { bool bit; uchar n;
    do
      { bit = gbit();
	if (bit < 0) return -1;
      }
    while (bit);
    for (int i=0; i < 8; i++)
      { bit = gbit();
	if (bit < 0) return -1;
	n = (n >> 1) | (bit << 7);
      }
    return n;
  }

static int gsync()
  { giveup("Bug! sync mode not supported in V.22");
  }

inline void insertbit(int b)
  { scrambler[1] <<= 1; if (scrambler[0] & 0x80000000) scrambler[1] |= 1;
    scrambler[0] <<= 1; if (b) scrambler[0] |= 1;
  }

inline uint sbit(int bn)
  { return (scrambler[0] >> bn) & 1;
  }

static int gbit()
  { if (v22_conrate == 0) return -1;	/* handshake failed */
    int bit = callco(bitco, 0);
    if (bit < 0) return -1;		/* carrier lost */
    insertbit(bit);
    return sbit(0) ^ sbit(14) ^ sbit(17);
  }

