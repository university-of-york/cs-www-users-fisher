/* Modem for MIPS   AJF	  January 1995
   Filter header file */

struct filter;

typedef float (*fstepfunc)(filter*, float);

struct fspec
  { int nz, np;
    fstepfunc fsf;
  };

struct filter
  { filter(fspec*);
    ~filter();
    float fstep(float x) { return fs -> fsf(this, x); }
    fspec *fs; float *v;
  };

struct cfilter
  { cfilter(fspec *fs)
      { ref = new filter(fs);
	imf = new filter(fs);
      }
    ~cfilter()
      { delete ref; delete imf;
      }
    complex fstep(complex z) { return complex(ref -> fstep(z.re), imf -> fstep(z.im)); }
    filter *ref, *imf;
  };

struct resonator
  { resonator(fspec *fs)
      { fi = new filter(fs);
	py = 0.0; count = 0;
      }
    ~resonator()
      { delete fi;
      }
    float fstep(float x)
      { count++;
	float y = fi -> fstep(x);
	/* reset count on low-to-high ZC */
	if (py < 0.0 && y >= 0.0) count = 0;
	py = y;
	return y;
      }
    filter *fi; float py; int count;
  };

