#include "complex.h"
#include "modem.h"
#include "filters.h"

/**** REAL BANDPASS (order 2) ****/

bp2_filter::bp2_filter(double *yc)
  { yco = yc;
    memclr(xv); memclr(yv);
  }

float bp2_filter::fstep(float x)
  { insert(x, xv, np);
    shiftdown(yv, np);
    yv[np] = (xv[0] + xv[4]) - 2.0 * xv[2]
	   + (yco[0] * yv[0]) + (yco[1] * yv[1]) + (yco[2] * yv[2]) + (yco[3] * yv[3]);
    return yv[np];
  }

/**** REAL BANDPASS (order 4) ****/

bp4_filter::bp4_filter(double *yc)
  { yco = yc;
    memclr(xv); memclr(yv);
  }

float bp4_filter::fstep(float x)
  { insert(x, xv, np);
    shiftdown(yv, np);
    yv[np] = (xv[0] + xv[8]) - 4.0 * (xv[2] + xv[6]) + 6.0 * xv[4]
	   + (yco[0] * yv[0]) + (yco[1] * yv[1]) + (yco[2] * yv[2]) + (yco[3] * yv[3])
	   + (yco[4] * yv[4]) + (yco[5] * yv[5]) + (yco[6] * yv[6]) + (yco[7] * yv[7]);
    return yv[np];
  }

/**** REAL LOWPASS ****/

lp2_filter::lp2_filter(double *yc)
  { yco = yc;
    memclr(xv); memclr(yv);
  }

float lp2_filter::fstep(float x)
  { insert(x, xv, np);
    shiftdown(yv, np);
    yv[np] = (xv[0] + xv[2]) + 2.0 * xv[1]
	   + (yco[0] * yv[0]) + (yco[1] * yv[1]);
    return yv[np];
  }

/**** COMPLEX LOWPASS ****/

clp_filter::clp_filter(double *yc)
  { yco = yc;
    memclr(xv); memclr(yv);
  }

complex clp_filter::fstep(complex x)
  { insert(x, xv, np);
    shiftdown(yv, np);
    yv[np] = (xv[0] + xv[4]) + 4.0 * (xv[1] + xv[3]) + 6.0 * xv[2]
	   + (yco[0] * yv[0]) + (yco[1] * yv[1]) + (yco[2] * yv[2]) + (yco[3] * yv[3]);
    return yv[np];
  }

/**** REAL RESONATOR ****/

resonator::resonator(double *yc)
  { yco = yc;
    memclr(xv); memclr(yv);
    count = 0;
  }

float resonator::fstep(float x)
  { count++;
    insert(x, xv, np);
    shiftdown(yv, np);
    yv[np] = (xv[2] - xv[0]) + (yco[0] * yv[0]) + (yco[1] * yv[1]);
    if (yv[np-1] < 0.0 && yv[np] >= 0.0) count = 0;	/* low-to-high ZC */
    return yv[np];
  }

