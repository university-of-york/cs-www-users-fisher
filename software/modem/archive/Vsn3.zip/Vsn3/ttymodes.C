/* Modem for Mips   AJF	  January 1996
   Set/reset tty modes (raw or cooked)
*/

#include <sgtty.h>
#include "modem.h"

struct ttymode		/* for setting raw/cooked tty input */
  { ttymode();
    ~ttymode();
  };

static ttymode ttymode;

static termios cmode, rmode;
static bool isatty;


ttymode::ttymode()
  { int code = tcgetattr(0, &cmode);			    /* fetch current tty mode	*/
    isatty = (code == 0);				    /* we might be in fax mode! */
    if (isatty)
      { rmode = cmode;					    /* copy the struct		*/
	rmode.c_iflag = rmode.c_oflag = rmode.c_lflag = 0;  /* modify for raw mode	*/
	rmode.c_cc[VMIN] = rmode.c_cc[VTIME] = 1;	    /* set timeout params	*/
      }
  }

ttymode::~ttymode()
  { if (isatty) setcooked();				    /* reset cooked (original) mode */
  }

global void setcooked()
  { unless (isatty) giveup("Bug! setcooked on non-tty");
    tcsetattr(0, TCSADRAIN, &cmode);			    /* set cooked mode (ignore errors) */
  }

global void setraw()
  { unless (isatty) giveup("Bug! setraw on non-tty");
    tcsetattr(0, TCSADRAIN, &rmode);			    /* set raw mode (ignore errors) */
  }

