#define SAVEFP	# must agree with defn in resume.s

/*
 * simple coroutine package
   This is a non-buggy version of /sys/src/libco/co.c
 */

#include <co.h>

#define global
#define NULL 0

typedef void (*proc)();
typedef unsigned int uint;

extern "C"
  { void _coresume(Context*, Context*);
    void main();
    void *malloc(uint);
    void free(void*);
  };

global Corout _mainco = { main };
global Corout *_currentco = &_mainco;
global Corout *_invokingco = &_mainco;

extern int _costart[];	/* bootstrap code */

static void _costackinit(Context*, proc, void*, uint);


global int cocreate(Corout *co, proc f, void *stack, uint stacksize)
  { co -> text = f;
    if (stacksize == 0) stacksize = 4096; /* not enough for Fprint */
    co -> stack = (int*) stack;
    co -> stacksize = stacksize;
    co -> mystack = 0;
    if (co -> stack == NULL)
      { co -> stack = (int*) malloc(co -> stacksize);
	if (co -> stack == NULL) return -1;
	co -> mystack = 1;
      }
    _costackinit(&co -> state, f, co -> stack, co -> stacksize);
    co -> data = NULL;
    return 0;
  }

global void coresume(Corout *other)
  { _invokingco = _currentco;
    _currentco = other;
    _coresume(&_invokingco -> state, &_currentco -> state);
  }

global void codestroy(Corout *co)
  { if (co != NULL && co -> stack != NULL && co -> mystack)
      { free(co -> stack);
	co -> stack = NULL;
	co -> mystack = 0;
      }
  }

static void _costackinit(Context *ctx, proc f, void *stack, uint stacksize)
  { /* locate the top of the stack */
    int *top = (int*) ((char*) stack + stacksize);

    /* the bootstrap image at the top of the stack consists of (from top down)
     * a zero for alignment, the return address,
     * 32 floating point register saves if requested,
     * 10 register saves:
     * locate the start of this area
     */

    int *sp = top - 12;
#ifdef SAVEFP
    sp -= 32;
#endif

    /* initialize the registers - first resume() restores these */
    int j = 0;
    for (int i=0; i < 9; i++) sp[j++] = 0;  /* callee saved registers */
    sp[j++] = (int) _costart;		    /* saved r31: return address */
#ifdef SAVEFP
    for (int i=0; i < 32; i++) sp[j++] = 0; /* 128 bytes of fp regs */
#endif

    /* plant the function address - used by _costart() */
    sp[j++] = (int) f;

    /* zero for alignment */
    sp[j++] = 0;

    /* finally set up the context for resume() */
    ctx -> sp = (int) sp;		    /* initial sp */
  }

