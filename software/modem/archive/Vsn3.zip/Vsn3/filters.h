struct bp4_filter		/* real bandpass filter (order 4) */
  { bp4_filter(double*);	/* constructor */
    float fstep(float);		/* filter step */
    const int np = 8;
    double *yco;
    float xv[np+1], yv[np+1];
  };

struct bp2_filter		/* real bandpass filter (order 2) */
  { bp2_filter(double*);	/* constructor */
    float fstep(float);		/* filter step */
    const int np = 4;
    double *yco;
    float xv[np+1], yv[np+1];
  };

struct lp2_filter		/* real lowpass filter (order 2) */
  { lp2_filter(double*);	/* constructor */
    float fstep(float);		/* filter step */
    const int np = 2;
    double *yco;
    float xv[np+1], yv[np+1];
  };

struct clp_filter		/* complex lowpass filter (order 4) */
  { clp_filter(double*);	/* constructor */
    complex fstep(complex);	/* filter step */
    const int np = 4;
    double *yco;
    complex xv[np+1], yv[np+1];
  };

struct resonator		/* real resonator */
  { resonator(double*);		/* constructor */
    float fstep(float);		/* filter step */
    const int np = 2;
    double *yco;
    float xv[np+1], yv[np+1];
    int count;
  };

