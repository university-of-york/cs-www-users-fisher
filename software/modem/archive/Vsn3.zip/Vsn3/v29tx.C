/* Modem for MIPS   AJF	  January 1995
   V.29 transmit routines */

#include <fishaudio.h>
#include "complex.h"
#include "modem.h"

#define SCALE	    (0.31 * MAXAMPL)
#define PHINC	    ((1700 * SINELEN) / SAMPLERATE)	/* 1700 Hz carrier */
#define BAUDLEN	    10					/* 2400 bd/sec	   */

/* tables for DPSK encoding */
static uchar phinctab[8] = { 1, 6, 2, 5, 0, 7, 3, 4 };

static c_complex constellation[16] =
  { { +3.0, 0.0 }, { +1.0, +1.0 }, { 0.0, +3.0 }, { -1.0, +1.0 },	/*  0 -	 3 */
    { -3.0, 0.0 }, { -1.0, -1.0 }, { 0.0, -3.0 }, { +1.0, -1.0 },	/*  4 -	 7 */
    { +5.0, 0.0 }, { +3.0, +3.0 }, { 0.0, +5.0 }, { -3.0, +3.0 },	/*  8 - 11 */
    { -5.0, 0.0 }, { -3.0, -3.0 }, { 0.0, -5.0 }, { +3.0, -3.0 },	/* 12 - 15 */
  };

static float shapetab[BAUDLEN+1] =
  { /* Raised cosine pulse shaping with Beta = 1.0 (see e.g. Proakis) */
    0.0000000000, 0.0464032383, 0.1212863347, 0.2252460502, 0.3543520014,
    0.5000000000, 0.6496453360, 0.7883611757, 0.9009842008, 0.9744680039,
    1.0000000000,
  };

static uint sineptr, scrambler;
static uchar sigelement, bitcount;
static complex prevampl;

static void init(vmode), pasync(int), psync(int), pbit(int), sendbaud();

global txhandler v29_txhandler = { init, pasync, psync, pbit };


static void init(vmode)
  { sineptr = 0;
    prevampl = 0.0;
    /* Segment 1 */
    sendpause(480);			    /* silence */
    /* Segment 2 */
    for (int i=0; i < 128; i++)
      { sigelement = (i & 1) ? 7 : 4;	    /* A or B */
	sendbaud();
      }
    /* Segment 3 */
    uchar reg = 0x2a;
    for (int i=0; i < 384; i++)
      { uint b6 = (reg >> 1) & 1;
	uint b7 = reg & 1;
	sigelement = b7 ? 3 : 0;	    /* C or D */
	sendbaud();
	reg >>= 1;
	if (b6 ^ b7) reg |= 0x40;
      }
    /* Segment 4 */
    scrambler = bitcount = 0;
    for (int i=0; i < 144; i++) pbit(1);	/* scrambled 1s */
  }

static void pasync(int)		/* asynchronous output */
  { giveup("Bug! async mode not supported in V.29");
  }

static void psync(int)		/* synchronous output */
  { giveup("Bug! sync mode not supported in V.29");
  }

static void pbit(int bit)		    /* V.29 bit output (7200 bit/s) */
  { int b18 = (scrambler >> 5) & 1;
    int b23 = scrambler & 1;
    bit = bit ^ b18 ^ b23;
    scrambler >>= 1;
    if (bit) scrambler |= 0x400000;
    if (++bitcount == 3)
      { uchar x = scrambler >> 20;			/* delta phase from most recent 3 bits */
	sigelement = (sigelement + phinctab[x]) & 7;
	sendbaud();
	bitcount = 0;
      }
  }

static void sendbaud()
  { complex ampl = constellation[sigelement];
    int n = 0;
    while (n < BAUDLEN)
      { /* baseband pulse shaping */
	float te_shape = shapetab[BAUDLEN-n];	   /* trailing-edge shape for previous pulse */
	float le_shape = shapetab[n];		   /* leading-edge shape for new pulse	     */
	complex sh_ampl = (te_shape * prevampl) + (le_shape * ampl);
	/* modulate onto carrier */
	int ip = sineptr & (SINELEN-1);
	int qp = (sineptr + SINELEN/4) & (SINELEN-1);
	float val = SCALE * ((sh_ampl.re * sinetab[ip]) + (sh_ampl.im * sinetab[qp]));
	if (val > MAXAMPL || val < -MAXAMPL) giveup("Bug! out of range (V.29 sendbaud): %08x", (int) val);
	Audio -> write((int) val);
	sineptr += PHINC; n++;
      }
    prevampl = ampl;
  }

