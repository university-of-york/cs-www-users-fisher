/* Modem for MIPS   AJF	  December 1995 */

#define V22_DEBUG	true	/* define as "true" or "false"                */
#define NPOINTS		4	/* 4 pts to left, 4 pts to right in equalizer */

/* Defns of signals for communicating from V.22 Rx to Tx */
#define sig_1200	33
#define sig_2400	34

extern vmode v22_mode;		/* from v22rx, used by v22_bitloop */
extern uint v22_conrate;	/* from v22rx, used by v22_bitloop */

extern void v22_bitloop();						/* from v22_bitloop */
extern void v22_initdebug(), v22_startdebug();				/* from v22_debug   */
extern void v22_recorddebug(complex, uint, complex*, float, float);	/* from v22_debug   */

