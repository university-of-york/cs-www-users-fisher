/* Modem for MIPS   AJF	  January 1995
   Coroutine routines */

#include <co.h>
#include "modem.h"

#define STACKSIZE   16384
#define MAXCOS	    2

union covalue { int i; float f; };

static Corout *coros[MAXCOS];
static int numcoros;

static void stopco(Corout*);

struct setup
  { setup();
    ~setup();
  };

static setup setup;

setup::setup()
  { numcoros = 0;
    _mainco.data = new covalue;
  }

setup::~setup()
  { while (numcoros > 0) stopco(coros[--numcoros]);
    delete _mainco.data;
  }

global Corout *startco(proc p)
  { int n = 0;
    while (n < numcoros)	/* kill any previous incarnations of this coroutine */
      { if (coros[n] -> text == p)
	  { stopco(coros[n]);
	    coros[n] = coros[--numcoros];
	  }
	else n++;
      }
    if (numcoros >= MAXCOS) giveup("Too many coroutines!");
    Corout *co = new Corout;
    int code = cocreate(co, p, NULL, STACKSIZE);
    unless (code == 0) giveup("cocreate failed");
    co -> data = new covalue;
    coros[numcoros++] = co;
    return co;
  }

static void stopco(Corout *co)
  { delete co -> data; codestroy(co); delete co;
  }

#undef codata	/* undefine macro def'd in co.h */

inline covalue *codata(Corout *co)
  { /* access co -> data as a "union covalue*" */
    return (covalue*) co -> data;
  }

global int icallco(Corout *co, int i)
  { codata(co) -> i = i;
    coresume(co);
    return codata(_currentco) -> i;
  }

global float fcallco(Corout *co, float f)
  { codata(co) -> f = f;
    coresume(co);
    return codata(_currentco) -> f;
  }

