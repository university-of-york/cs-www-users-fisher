/* Modem for MIPS   AJF	  December 1995
   V.22 receive routines
*/

#include <co.h>
#include <fishaudio.h>
#include "complex.h"
#include "modem.h"
#include "filters.h"
#include "v22.h"

#define BAUDSPS	    600			/* bauds per sec		    */
#define BAUDLEN	    40			/* samples per baud		    */
#define THRESHOLD   1e11		/* carrier detect threshold	    */

/* automatic gain control parameters */
#define AGCFAC	    0.99995		/* for agc lpf			    */
#define TYP_AMPL    2e4			/* typical i/c line amplitude	    */
#define INIT_AMPL   (10.0 * TYP_AMPL)	/* initial gain is 0.1, adj by agc  */
#define GFACTOR	    2.135		/* gain factor, before equalization */

/* equalization parameters */
#define EQLEN	    300			/* equalize over 0.5 sec	    */
#define MAX_DELTAC  1e-6
#define MIN_DELTAC  1e-30
#define DELTAPHI    0.01
#define INITE0	    2.0			/* must be suff. large to ensure convergence to correct state */

static double bp_coeffs[2][bp4_filter::np] =
  { { -0.6630104844, +4.5251046761, -14.5157382898, +28.2019444330,		/* Bu Bp 2100 .. 2700 Hz */
      -36.1502905020, +31.2545072472, -17.8281695379, +6.1592104879 },

    { -0.6630104844, +5.3195795874, -18.9433682149, +39.0847521667,		/* Bu Bp  900 .. 1500 Hz */
      -51.0880587708, +43.3162291990, -23.2667680099, +7.2405861811 },
  };

static double lp_coeffs[clp_filter::np] =
  { -0.6630104844, +2.9240526562, -4.8512758825, +3.5897338871 };		/* Bu Lp 600 Hz		 */

static double res_coeffs[resonator::np] = { -0.9998429327, +1.9752215477 };	/* resonator at 600 Hz	 */

static complex eqcoeffs[2*NPOINTS+1];
static float meanampl, resampl;

static void processbaud(complex, complex&);


global void v22_bitloop()
  { int cf = (v22_mode == V22o) ? 2400 : 1200;		/* carrier frequency */
    int phinc = (cf * SINELEN) / SAMPLERATE;
    bp4_filter bpf(bp_coeffs[v22_mode - V22o]);		/* front-end bandpass filter */
    clp_filter lpf(lp_coeffs);				/* baseband lowpass filter   */
    resonator res(res_coeffs);				/* baud rate resonator	     */
    complex eqin[2*NPOINTS+1];
    float eqcp[4];
    memclr(eqin); memclr(eqcoeffs);
    eqcoeffs[NPOINTS] = INITE0; eqcp[1] = eqcp[2] = eqcp[3] = INITE0;
    uint sineptr = 0;
    float deltac = MAX_DELTAC;
    meanampl = INIT_AMPL;
    for (;;)
      { complex gvec[2*NPOINTS+1]; memclr(gvec);
	int bc = 0;	    /* baud counter */
	while (bc < EQLEN)  /* update coeffs every EQLEN bauds */
	  { /* read next sample */
	    float x = (float) Audio -> read();
	    float y = bpf.fstep(x * 1e-10);			/* scale to avoid overflow later */
	    meanampl = (AGCFAC * meanampl) + fabsf(y);		/* estimate mean amplitude for agc */
	    /* translate to baseband */
	    complex bz = complex(y * sinetab[sineptr & (SINELEN-1)],
				 y * sinetab[(sineptr + SINELEN/4) & (SINELEN-1)]);
	    complex yz = lpf.fstep(bz);				/* low-pass filter at baud rate */
	    /* recover baud clock */
	    float yr = res.fstep(power(yz));			/* resonator at baud rate */
	    if (res.count == BAUDLEN/4)				/* symbol sampling time */
	      { resampl = yr;
		if (resampl < THRESHOLD) icallco(_invokingco, -1);  /* no carrier */
		insert(yz * (GFACTOR / meanampl), eqin, 2*NPOINTS); /* apply agc */
		complex z = 0.0; complex eps;
		for (int i=0; i < 2*NPOINTS+1; i++) z += (eqcoeffs[i] * eqin[i]);
		processbaud(z, eps);
		for (int i=0; i < 2*NPOINTS+1; i++) gvec[i] += eps * cconj(eqin[i]);
		bc++;
	      }
	    sineptr += phinc;
	  }
	/* adj equalizer coeffs */
	for (int i=0; i < 2*NPOINTS+1; i++) eqcoeffs[i] += deltac * gvec[i];
	insert(power(eqcoeffs[NPOINTS]), eqcp, 3);
	/* adaptive step size selection */
	bool e1 = (eqcp[0] < eqcp[1]), e2 = (eqcp[1] < eqcp[2]), e3 = (eqcp[2] < eqcp[3]);
	if (e1 == e2 && e2 == e3)
	  { if (deltac < 0.5 * MAX_DELTAC) deltac *= 2.0;
	  }
	else
	  { if (deltac > 2.0 * MIN_DELTAC) deltac *= 0.5;
	  }
      }
  }

static uchar decode[64] =
  { 0x4, 0x5, 0x6, 0x7, 0xc, 0xe, 0xd, 0xf, 0x0, 0x2, 0x1, 0x3, 0x8, 0x9, 0xa, 0xb,
    0x0, 0x1, 0x2, 0x3, 0x4, 0x6, 0x5, 0x7, 0x8, 0xa, 0x9, 0xb, 0xc, 0xd, 0xe, 0xf,
    0xc, 0xd, 0xe, 0xf, 0x8, 0xa, 0x9, 0xb, 0x4, 0x6, 0x5, 0x7, 0x0, 0x1, 0x2, 0x3,
    0x8, 0x9, 0xa, 0xb, 0x0, 0x2, 0x1, 0x3, 0xc, 0xe, 0xd, 0xf, 0x4, 0x5, 0x6, 0x7,
  };

static c_complex dztab[16] =
  { { -1.0, +1.0 }, { -1.0, +3.0 }, { -3.0, +1.0 }, { -3.0, +3.0 },
    { +1.0, +1.0 }, { +1.0, +3.0 }, { +3.0, +1.0 }, { +3.0, +3.0 },
    { -1.0, -1.0 }, { -1.0, -3.0 }, { -3.0, -1.0 }, { -3.0, -3.0 },
    { +1.0, -1.0 }, { +1.0, -3.0 }, { +3.0, -1.0 }, { +3.0, -3.0 },
  };

static void processbaud(complex z, complex &eps)
  { static uchar pb = 0;	/* for differential decoding */
    static uint phi = 0;
    complex w = complex(+sinetab[(phi+SINELEN/4) & (SINELEN-1)],
			-sinetab[phi & (SINELEN-1)]);	/* exp (-j phi) */
    complex dz = z * cconj(w);
    if (V22_DEBUG) v22_recorddebug(dz, phi, eqcoeffs, meanampl, resampl);
    pb >>= 2;	/* keep "quadrant" bits, clear rest */
    switch (v22_conrate)
      { case bps_1200:
	  { uint b1 = (dz.im < -0.5*dz.re), b2 = (dz.re > +0.5*dz.im);
	    pb = (pb << 1) | b1;
	    pb = (pb << 1) | b2;
	    pb = (pb << 2) | ((b1^b2) ? 2 : 1);
	    uchar d = decode[pb & 0x3f];
	    for (int i=0; i<2; i++) { icallco(_invokingco, d & 0x8); d <<= 1; }
	    break;
	  }

	case bps_2400:
	  { pb = (pb << 1) | (dz.im < 0.0);
	    pb = (pb << 1) | (dz.re > 0.0);
	    pb = (pb << 1) | (dz.re > +2.0 || dz.re < -2.0);
	    pb = (pb << 1) | (dz.im > +2.0 || dz.im < -2.0);
	    uchar d = decode[pb & 0x3f];
	    for (int i=0; i<4; i++) { icallco(_invokingco, d & 0x8); d <<= 1; }
	    break;
	  }
      }
    complex iz = dztab[pb & 0xf] * w;
    eps = z * (power(iz) - power(z));
    phi += (int) (DELTAPHI * (float) SINELEN * (iz * cconj(z)).im);
  }

