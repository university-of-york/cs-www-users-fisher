/* Modem for MIPS   AJF	  January 1995
   FSK receive routines */

#include <co.h>
#include <fishaudio.h>
#include "complex.h"
#include "modem.h"
#include "filters.h"

/* Bandpass filter coeffs constructed by:
   mkfilter -Bu -Bp -o 2 -a (A1) (A2)
   where A1 = (F0 - Bd/2) / 24000, A2 = (F0 + Bd/2) / 24000 */

static double bpcoeffs[][bp2_filter::np] =
  { { -0.9672274282, 3.8810890047, -5.8602627847, 3.9462973237 },     /*  345 ..  435 Hz, centre  390 Hz    [0] */
    { -0.9672274282, 3.8743642087, -5.8467815911, 3.9394595407 },     /*  405 ..  495 Hz, centre  450 Hz    [1] */
    { -0.8948743446, 3.5611124630, -5.4347481234, 3.7646386872 },     /*  830 .. 1130 Hz, centre  980 Hz    [2] */
    { -0.8948743446, 3.5073377192, -5.3284721717, 3.7077905862 },     /* 1030 .. 1330 Hz, centre 1180 Hz    [3] */
    { -0.6413515381, 2.7140236821, -4.4779393329, 3.3986058666 },     /*  700 .. 1900 Hz, centre 1300 Hz    [4] */
    { -0.8948743446, 3.3434382209, -5.0145298690, 3.5345238336 },     /* 1500 .. 1800 Hz, centre 1650 Hz    [5] */
    { -0.8948743446, 3.2581883313, -4.8571760711, 3.4444017059 },     /* 1700 .. 2000 Hz, centre 1850 Hz    [6] */
    { -0.6413515381, 2.4548946977, -3.9475276189, 3.0741144880 },     /* 1500 .. 2700 Hz, centre 2100 Hz    [7] */
  };

/* Lpwpass filter coeffs constructed by:
   mkfilter -Bu -Lp -o 2 -a (A1)
   where A1 = (Bd/2) / 24000 */

static double lpcoeffs[][lp2_filter::np] =
  { { -0.9862119292, 1.9861162115 },	/*  37.5 Hz   [0] */
    { -0.9459779362, 1.9444776578 },	/* 150	 Hz   [1] */
    { -0.8008026467, 1.7786317778 },	/* 600	 Hz   [2] */
  };

struct info
  { int bd;		  /* baud rate				   */
    double *lpco;	  /* low-pass filter coeffs		   */
    double *bpco[2];	  /* bandpass filter coeffs for 0, 1 tones */
  };

static info infotab[] =
  { {  300, lpcoeffs[1], bpcoeffs[6], bpcoeffs[5] },	 /* V21o */
    {  300, lpcoeffs[1], bpcoeffs[3], bpcoeffs[2] },	 /* V21a */
    { 1200, lpcoeffs[2], bpcoeffs[7], bpcoeffs[4] },	 /* V23o */
    {	75, lpcoeffs[0], bpcoeffs[1], bpcoeffs[0] },	 /* V23a */
  };

static ushort hbitlen;
static Corout *syncco;

/* init'ed so that first "delete" doesn't fail */
static bp2_filter *bpf[2] = { NULL, NULL };
static lp2_filter *lpf[2] = { NULL, NULL };

static void init(vmode), syncloop();
static int gasync(), gsync(), gbit();
static bool getsample();

global rxhandler fsk_rxhandler = { init, gasync, gsync, gbit };


static void init(vmode mode)
  { unless (mode >= 0 && mode < 4) giveup("Bug! bad mode %d in fsk rx init", mode);
    info *inf = &infotab[mode];
    for (int i=0; i<2; i++)
      { delete bpf[i]; bpf[i] = new bp2_filter(inf -> bpco[i]);
	delete lpf[i]; lpf[i] = new lp2_filter(inf -> lpco);
      }
    hbitlen = SAMPLERATE / (2 * inf -> bd);	/* num. samples in half a bit */
    Audio -> idiscard();    /* empty Rx ring buffer */
    syncco = startco(syncloop);
  }

static int gasync()	/* asynchronous input */
  { bool bit; int i, j; uchar n;
    do bit = getsample(); while (bit);
    for (j=0; j < 3*hbitlen; j++) bit = getsample();
    for (i=0; i < 8; i++)
      { n = (n >> 1) | (bit << 7);
	for (j=0; j < 2*hbitlen; j++) bit = getsample();
      }
    return n;
  }

static int gsync()	/* synchronous input */
  { return icallco(syncco);
  }

static int gbit()	/* bit input */
  { giveup("Bug: bit input not supported in fsk modes");
  }

static void syncloop()
  { uchar valid = 0, framing = 0x55, bitcount = 0;
    uchar thebits, thechar;
    for (;;)
      { int j = 0; bool bit;
	while (j < 2*hbitlen)
	  { bit = getsample();
	    framing = (framing << 1) | bit;
	    if (framing == 0xf0 || framing == 0x0f) j = hbitlen+4; else j++;
	  }
	thebits = (thebits << 1) | bit;
	valid = (valid << 1) | 1;
	switch (thebits)
	  { case 0x7c:	case 0x7d:
		valid &= ~2;	/* delete bit-stuffing */
		break;

	    case 0x7e:
		icallco(_invokingco, HDLC_FLAG);
		valid = bitcount = 0;
		break;

	    case 0x7f:
		icallco(_invokingco, HDLC_ABORT);
		valid = bitcount = 0;
		break;
	  }
	if (valid & 0x80)
	  { thechar = (thechar << 1) | (thebits >> 7);
	    if (++bitcount == 8)
	      { icallco(_invokingco, thechar);
		bitcount = 0;
	      }
	  }
      }
  }

static bool getsample()
  { float x = (float) Audio -> read() * 1e-10;	/* scale to avoid overflow */
    float p[2];
    for (int i=0; i<2; i++)
      { float y = bpf[i] -> fstep(x);
	p[i] = lpf[i] -> fstep(sqr(y));
      }
    return (p[1] >= p[0]);
  }

