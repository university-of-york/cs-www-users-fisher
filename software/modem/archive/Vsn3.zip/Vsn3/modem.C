/* Modem for MIPS   AJF	  January 1995
   Modem routines */

#include <stdio.h>
#include <signal.h>
#include "modem.h"

#define NOCHAR (-3)

static void sighandler(int), rxloop(vmode), txloop(vmode);
static int nextchar();


global void becomemodem(vmode mode)
  { setraw();					/* set raw tty mode		 */
    setbuf(stdout, NULL);			/* unbuffered stdout		 */
    int ppid = getpid();
    int cpid = fork();
    if (cpid < 0) giveup("fork failed");
    if (cpid == 0)
      { signal(SIGUSR1, SIG_DFL);		/* child: if we're killed we die */
	rxloop(mode);
	kill(ppid, SIGUSR1);			/* carrier loss: kill parent	 */
	_exit(0);				/* exit w/o cleaning up		 */
      }
    else
      { signal(SIGUSR1, (SIG_PF) sighandler);	/* parent			 */
	txloop(mode);
	kill(cpid, SIGUSR1);			/* EOF from terminal: kill child */
      }
    setcooked();				/* reset cooked mode		 */
  }

static void sighandler(int)
  { giveup("Carrier loss");
  }

static void rxloop(vmode mode)
  { /* forked as a child */
    initrx(mode);
    int ch = getaval();		/* from 'phone line */
    while (ch >= 0)		/* until carrier loss or killed by parent */
      { putchar(ch);		/* to stdout */
	ch = getaval();		/* from 'phone line */
      }
  }

static void txloop(vmode mode)
  { inittx(mode);
    bool ok = true;
    while (ok)
      { int ch = nextchar();	/* from stdin */
	switch (ch)
	  { default:
	      { putaval(ch);	/* to line */
		static char prev[3] = { 0, 0, 0 };
		prev[0] = prev[1]; prev[1] = ch;
		if (seq(prev,"\033\032")) ok = false;  /* termination sequence is ESC CTLZ */
		break;
	      }

	    case NOCHAR:
		putbit(1);	/* send mark while idle */
		break;

	    case EOF:
		ok = false;
		break;
	  }
      }
  }

static int nextchar()
  { int ch;
    if (stdin -> _cnt > 0) ch = getchar();
    else
      { uint ib = 1; /* test stdin */
	int tmo[2] = { 0, 0 }; /* immediate return */
	int nb = select(32, &ib, NULL, NULL, tmo);
	ch = (nb > 0) ? getchar() : NOCHAR;
      }
    return ch;
  }

