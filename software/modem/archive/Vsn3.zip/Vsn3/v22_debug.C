#include <stdio.h>
#include "complex.h"
#include "modem.h"
#include "v22.h"

#define DEBUGLEN 600

struct debug
  { complex z;
    uint phi;
  };

static debug debugbuf[DEBUGLEN];
static int debugptr;

static void printdebug(complex*, float, float);
static void prdebug(char*, complex*, float, float);


global void v22_initdebug()
  { debugptr = -1;	/* means "not collecting */
  }

global void v22_startdebug()
  { fprintf(stderr, "?? Collecting debug\r\n");
    debugptr = 0;
  }

global void v22_recorddebug(complex dz, uint phi, complex *eqc, float meanampl, float resampl)
  { if (debugptr >= 0)
      { debugbuf[debugptr].z = dz;
	debugbuf[debugptr].phi = phi;
	if (++debugptr >= DEBUGLEN)
	  { printdebug(eqc, meanampl, resampl);
	    debugptr = -1;
	  }
      }
  }

static void printdebug(complex *eqc, float meanampl, float resampl)
  { int cpid = fork();
    if (cpid < 0) giveup("fork failed");
    if (cpid == 0)
      { /* child */
	prdebug("debug1.grap", eqc, meanampl, resampl);
	_exit(0);
      }
  }

static void prdebug(char *fn, complex *eqc, float meanampl, float resampl)
  { fprintf(stderr, "?? printing debug to %s\r\n", fn);
    FILE *fi = fopen(fn, "w");
    if (fi == NULL) giveup("debug fopen failed");
    fprintf(fi, ".sp 0.5i\n.G1 8i\n");
    for (int j=0; j < DEBUGLEN; j++)
      { complex z = debugbuf[j].z;
	fprintf(fi, "%g %g\n", z.re, z.im);
      }
    fprintf(fi, ".G2\n.bp\n");
    fprintf(fi, ".sp 0.5i\n.G1 8i\n");
    fprintf(fi, "new solid\n");
    for (int j=0; j < DEBUGLEN; j++) fprintf(fi, "%d %g\n", j, (TWOPI/SINELEN) * (debugbuf[j].phi & (SINELEN-1)));
    fprintf(fi, ".G2\n.bp\n");
    fprintf(fi, ".sp 0.5i\n.G1 8i\n");
    fprintf(fi, "new solid\n");
    for (int j=0; j < 2*NPOINTS+1; j++) fprintf(fi, "%d %g\n", j-NPOINTS, eqc[j].re);
    fprintf(fi, "new dashed\n");
    for (int j=0; j < 2*NPOINTS+1; j++) fprintf(fi, "%d %g\n", j-NPOINTS, eqc[j].im);
    fprintf(fi, ".G2\n.bp\n");
    for (int j=0; j < 2*NPOINTS+1; j++) fprintf(fi, "{ %10.6f, %10.6f },\n", eqc[j].re, eqc[j].im);
    fprintf(fi, "meanampl = %g   resampl = %g\n", meanampl, resampl);
    fclose(fi);
    fprintf(stderr, "?? done\r\n");
  }

