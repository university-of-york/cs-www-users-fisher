/* Modem for MIPS   AJF	  December 1995
   V.22 transmit routines */

#include <signal.h>
#include <fishaudio.h>
#include "complex.h"
#include "modem.h"
#include "v22.h"

#define SCALE	    (0.10 * MAXAMPL)	/* was 0.20 */
#define PHINC_O	    ((1200 * SINELEN) / SAMPLERATE)	/* 1200 Hz carrier */
#define PHINC_A	    ((2400 * SINELEN) / SAMPLERATE)	/* 2400 Hz carrier */
#define BAUDLEN	    40					/* num. samples per baud (600 bd/sec)  */

#define slowrequest (1 << 30)	/* bit set in conrate by signal handler */
#define fastrequest (1 << 31)	/* bit set in conrate by signal handler */

static float shapetab[2*BAUDLEN+1] =
  { /* Raised cosine pulse shaping with Beta = 1.0 (see e.g. Proakis) */
     1.0000000000,  0.9983887070,  0.9935673162,  0.9855731581,	 0.9744680039,	0.9603374039,  0.9432897707,  0.9234552228,
     0.9009842008,  0.8760458747,  0.8488263632,  0.8195267860,	 0.7883611757,	0.7555542732,  0.7213392364,  0.6859552885,
     0.6496453360,  0.6126535847,  0.5752231831,  0.5375939192,	 0.5000000000,	0.4626679374,  0.4258145641,  0.3896452020,
     0.3543520014,  0.3201124680,  0.2870881911,  0.2554237850,	 0.2252460502,	0.1966633596,  0.1697652726,  0.1446223740,
     0.1212863347,  0.0997901870,  0.0801488040,  0.0623595717,	 0.0464032383,	0.0322449255,  0.0198352822,  0.0091117613,
     0.0000000000, -0.0075847203, -0.0137359537, -0.0185545334, -0.0221470001, -0.0246240360, -0.0260989265, -0.0266860671,
    -0.0264995353, -0.0256517426, -0.0242521818, -0.0224062833, -0.0202143891, -0.0177708552, -0.0151632873, -0.0124719143,
    -0.0097691028, -0.0071190095, -0.0045773728, -0.0021914363,	 0.0000000000,	0.0019664090,  0.0036852559,  0.0051416177,
     0.0063277143,  0.0072423635,  0.0078903731,  0.0082818829,	 0.0084316703,	0.0083584330,  0.0080840606,  0.0076329097,
     0.0070310919,  0.0063057873,  0.0054845933,  0.0045949158,	 0.0036634135,	0.0027154985,  0.0017748997,  0.0008632931,
     0.0000000000,
  };

static c_complex constellation[16] =
  { { +1.0, +1.0 }, { +3.0, +1.0 }, { +1.0, +3.0 }, { +3.0, +3.0 },	/* Phase Quadrant 1 */
    { -1.0, +1.0 }, { -1.0, +3.0 }, { -3.0, +1.0 }, { -3.0, +3.0 },	/* Phase Quadrant 2 */
    { -1.0, -1.0 }, { -3.0, -1.0 }, { -1.0, -3.0 }, { -3.0, -3.0 },	/* Phase Quadrant 3 */
    { +1.0, -1.0 }, { +1.0, -3.0 }, { +3.0, -1.0 }, { +3.0, -3.0 },	/* Phase Quadrant 4 */
  };

static vmode themode;
static uint sineptr, scrambler, conrate;
static uchar sigelement, bitcount;
static complex ampls[4];

static void init(vmode), catchsignal(int), pasync(int), psync(int), pbit(int);
static void sendfastsignal(), pbit_1200(int), pbit_2400(int), senddibit(uchar), sendquadbit(uchar), sendbaud();

global txhandler v22_txhandler = { init, pasync, psync, pbit };


static void init(vmode mode)
  { unless (mode == V22o || mode == V22a) giveup("Bug! bad mode %d in V.22 tx init", mode);
    themode = mode;
    signal(sig_1200, (SIG_PF) catchsignal);
    signal(sig_2400, (SIG_PF) catchsignal);
    sighold(sig_1200); sighold(sig_2400);   /* disable interrupts */
    sineptr = bitcount = sigelement = 0;
    for (int i=0; i < 4; i++) ampls[i] = 0.0;
    conrate = bps_1200; /* handshaking done at 1200 bps */
    sigrelse(sig_1200); sigrelse(sig_2400); /* enable interrupts */
    switch (themode)
      { case V22o:	/* originate */
	    sendpause(84000);	/* silence for 3.5 sec */
	    if (bitrates & bps_2400) sendfastsignal();
	    break;

	case V22a:	/* answer */
	    /* send unscrambled 1 until we receive a reply; 5 sec timeout */
	    int n = 0;
	    until ((conrate & (slowrequest | fastrequest)) || (n >= 3000))
	      { Audio -> owait(SAMPLERATE/10);	/* don't let Tx buffer become more than 100 ms full */
		senddibit(3);
		n++;
	      }
	    unless (conrate & (slowrequest | fastrequest)) giveup("handshake failed");
	    break;
      }
    scrambler = 0;
    for (int i=0; i < 600; i++) pbit(1);    /* scrambled 1 */
  }

static void catchsignal(int sig)
  { switch (sig)
      { case sig_1200:
	    infomsg("Connected at 1200 bps");
	    conrate = bps_1200 | slowrequest;
	    break;

	case sig_2400:
	    infomsg("Connected at 2400 bps");
	    conrate = bps_2400 | fastrequest;
	    break;
      }
  }

static void pasync(int n)	/* asynchronous output */
  { uint un = (n << 1) | 0x600; /* add start bit, 2 stop bits */
    until (un == 0) { pbit(un & 1); un >>= 1; }
  }

static void psync(int)		/* synchronous output */
  { giveup("Bug! sync mode not supported in V.22");
  }

inline void insertbit(int b)
  { scrambler <<= 1; if (b) scrambler |= 1;
  }

inline uint sbit(int bn)
  { return (scrambler >> bn) & 1;
  }

static void pbit(int bit)
  { if (conrate & fastrequest) sendfastsignal();
    conrate &= ~(fastrequest | slowrequest);
    switch (conrate)
      { case bps_1200:
	    pbit_1200(bit);
	    break;

	case bps_2400:
	    pbit_2400(bit);
	    break;
      }
  }

static void sendfastsignal()
  { /* send "fast" signal (S1) */
    for (int i=0; i < 30; i++) { senddibit(0); senddibit(3); }
    // for (int i=0; i < 360; i++) pbit_1200(1);    /* do we need this? */
  }

static void pbit_1200(int bit)
  { bit = bit ^ sbit(13) ^ sbit(16);
    insertbit(bit);
    if (++bitcount == 2)
      { uchar x = scrambler & 0x3;	/* most recent 2 bits */
	senddibit(x);
	bitcount = 0;
      }
  }

static void pbit_2400(int bit)
  { bit = bit ^ sbit(13) ^ sbit(16);
    insertbit(bit);
    if (++bitcount == 4)
      { uchar x = scrambler & 0xf;	/* most recent 4 bits */
	sendquadbit(x);
	bitcount = 0;
      }
  }

static void senddibit(uchar x)
  { sendquadbit((x << 2) | 2);	/* at 1200 bps, element within quadrant is always 10 */
  }

static void sendquadbit(uchar x)
  { static uchar phinctab[4] = { 4, 0, 8, 12 };
    sigelement = (sigelement + phinctab[x >> 2]) & 0x0c; /* determine phase change  */
    sigelement |= (x & 3);				 /* element within quadrant */
    sendbaud();
  }

static void sendbaud()
  { uint phinc = (themode == V22a) ? PHINC_A : PHINC_O; /* orig or ans mode? */
    insert(constellation[sigelement], ampls, 3);
    int n = 0;
    while (n < BAUDLEN)
      { /* baseband pulse shaping */
	complex s = shapetab[BAUDLEN+n]	  * ampls[0]
		  + shapetab[n]		  * ampls[1]
		  + shapetab[BAUDLEN-n]	  * ampls[2]
		  + shapetab[2*BAUDLEN-n] * ampls[3];
	/* modulate onto carrier */
	int ip = sineptr & (SINELEN-1);
	int qp = (sineptr + SINELEN/4) & (SINELEN-1);
	float val = SCALE * (s.re * sinetab[ip] + s.im * sinetab[qp]);
	if (val > MAXAMPL || val < -MAXAMPL) giveup("Bug! out of range (V.22 sendbaud): %08x", (int) val);
	Audio -> write((int) val);
	sineptr += phinc; n++;
      }
  }

