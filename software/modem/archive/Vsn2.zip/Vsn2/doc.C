/* Modem for MIPS   AJF	  January 1995
   Send a document (T.4), in Group 3 format on stdin */

#include <stdio.h>
#include <fishaudio.h>
#include "modem.h"

#define SEGSIZE	 64000
#define MAXLINES 2400
#define VERSION	 1

static uchar *docpage;
static int pagebits, pagenum, ch;

static void formaterror();

#ifdef DEBUG
static void dofft();
#endif


global void initdoc()
  { int vsn, xres, yres;
    int ni = scanf("!<Group 3> %d %d %d\n", &vsn, &xres, &yres);
    unless (ni == 3 && vsn == VERSION && xres == 200 && (yres == 100 || yres == 200)) formaterror();
    if (yres == 200) options |= opt_H;
    pagenum = 0;
    docpage = NULL;
    ch = getchar(); /* read 1 char ahead */
    morepages = (ch >= 0);
  }

global void readdocpage()
  { /* Read a single page */
    unless (morepages) giveup("Bug! readdocpage");
    docpage = (docpage == NULL) ? (uchar*) malloc(SEGSIZE) : (uchar*) realloc(docpage, SEGSIZE);
    int *blvec = (int*) malloc(MAXLINES * sizeof(int));
    if (docpage == NULL || blvec == NULL) giveup("No room!");
    pagenum++; pagebits = 0;
    uint prevbits = ~0; int nbytes = 0, neols = 0, blnum = 0;
    until (nbytes >= SEGSIZE || neols >= 6)
      { uchar n;
	if (ch < 0) formaterror();
	docpage[nbytes++] = n = ch;
	for (int j=0; j < 8 && neols < 6; j++)
	  { prevbits = (prevbits << 1) | (n >> 7);
	    n <<= 1; pagebits++;
	    /* 7 consecutive EOLs mark end of page; note that 2 consec. EOLs never occur in body of page */
	    if ((prevbits & 0xffffff) == 0x001001) neols++;
	    if ((prevbits & 0x1fffffff) == 0x09b35001)	/* 1728 white + 0 white + EOL, i.e. blank line */
	      { if (blnum >= MAXLINES) giveup("Page %d: too long!", pagenum);
		blvec[blnum++] = pagebits;   /* keep track of ends of blank lines */
	      }
	  }
	ch = getchar();
      }
    if (neols < 6) giveup("Page %d: too big!", pagenum);
    /* delete RTC signal (6 EOLs), and trailing blank lines */
    pagebits -= 72;
    while (blnum > 0 && blvec[blnum-1] == pagebits) { pagebits -= 29; blnum--; }
    nbytes = (pagebits+7) / 8;
    infomsg("Page %2d: %5d bytes, %6d bits", pagenum, nbytes, pagebits);
    realloc(docpage, nbytes);
    free(blvec);
    morepages = (ch >= 0);
  }

static void formaterror()
  { giveup("Input is not in Group 3 format");
  }

#ifdef DEBUG

global int debugnum = -1;
global float debugbuf[12000];

static float debugtot[4096];

extern "C" double log10(double);

global void senddocpage()
  { /* Debugging version computes spectrum */
    int i, j;
    for (i=0; i < 4096; i++) debugtot[i] = 0.0;
    for (j=0; j < 100; j++)
      { fprintf(stderr, "Collecting %d\n", j);
	debugnum = 0;
	for (i=0; i < 7200; i++) putbit(1);
	dofft(debugbuf);
	for (i=0; i < 4096; i++) debugtot[i] += debugbuf[i];
      }
    FILE *fi = fopen("debug.dat", "w");
    if (fi == NULL) giveup("debug fopen 1 failed");
    for (i=0; i < 4096; i++) fprintf(fi, "%g\t%g\n", (float) i * (6000.0 / 4096.0), 10.0 * log10(debugtot[i]));
    fclose(fi);
    giveup("debug exit");
  }

static void dofft()
  { int i; FILE *fi;
    fi = popen("fft -p | tac /tmp/tmp", "w");
    if (fi == NULL) giveup("debug popen failed");
    for (i=0; i < 8192; i++) fprintf(fi, "%g\n", debugbuf[i]);
    int code = pclose(fi);
    if (code != 0) giveup("debug pclose failed");
    fi = fopen("/tmp/tmp", "r");
    if (fi == NULL) giveup("debug fopen 2 failed");
    for (i=0; i < 4096; i++)
      { int ni = fscanf(fi, "%g\n", &debugbuf[i]);
	unless (ni == 1) giveup("debug scanf failed, ni=%d, i=%d", ni, i);
      }
    fclose(fi);
  }

#else

global void senddocpage()
  { if (options & opt_v) fprintf(stderr, ">>> Page %d\n", pagenum);
    uchar *ptr = docpage;
    int nb = 0;
    int lb = scanbits; /* don't pad first EOL */
    uint prevbits = ~0;
    while (nb < pagebits)
      { uchar n = *(ptr++);
	for (int j=0; j < 8 && nb < pagebits; j++)
	  { uchar bit = n >> 7;
	    prevbits = (prevbits << 1) | bit;
	    if ((prevbits & 0xfff) == 0x001)	/* EOL */
	      { while (lb++ < scanbits) putbit(0);  /* pad scan line to achieve min. scan time */
		lb = 0;
	      }
	    putbit(bit);
	    lb++; nb++; n <<= 1;
	  }
      }
    /* send RTC (6 further EOLs) plus 2 more "for luck", to flush tribit buffer */
    for (int i=0; i < 8; i++)
      { for (int j=0; j < 11; j++) putbit(0);
	putbit(1);
      }
  }

#endif

