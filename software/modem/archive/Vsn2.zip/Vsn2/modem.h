#define global
#define bool	    int
#define false	    0
#define true	    1
#define unless(x)   if(!(x))
#define until(x)    while(!(x))
#define seq(s1,s2)  (strcmp(s1,s2) == 0)

/* the following relies on memcpy's working with overlapping areas (which it does) */
#define shiftdown(v,n) memcpy(&v[0], &v[1], (n) * sizeof(float));

#define SAMPLERATE  24000
#define SINELEN	    32768	/* power of 2 */
#define PI	    3.14159265358979323846
#define TWOPI	    (2.0 * PI)
#define MAXAMPL	    (float) 0x3fffff	/* max amplitude for ADC, DAC (h/w accepts 0x7fffff) */

#define HDLC_FLAG   (-1)
#define HDLC_ABORT  (-2)

#define DIAL_TONE   1
#define MERC_TONE   2
#define CONN_TONE   3

#define NULL	    0

/* cmd line and other options */
#define opt_fax	    0x01    /* -fax : fax call	    */
#define opt_mod	    0x02    /* -V.. : modem call    */
#define opt_v	    0x04    /* -v : verbose	    */
#define opt_m	    0x08    /* -m : use Mercury 131 */
#define opt_p	    0x10    /* -p : private call    */
#define opt_H	    0x20    /* high resolution	    */

typedef unsigned char uchar;
typedef unsigned int uint;
typedef unsigned short ushort;
typedef int word;		/* or char* or ...	 */
typedef void (*proc)();		/* proc taking no args	 */

struct complex { float re, im; };

inline complex operator * (float a, complex z)
  { z.re *= a; z.im *= a;
    return z;
  }

inline complex operator + (complex z1, complex z2)
  { z1.re += z2.re;
    z1.im += z2.im;
    return z1;
  }

extern int errno;			/* from sys lib */

extern audio tx_audio, rx_audio;	/* from main */
extern float sinetab[];			/* from main */
extern int contime, pagessent;		/* from main */
extern ushort scanbits;			/* from main */		/* set by fax, used by senddoc */
extern bool morepages;			/* from main */		/* set by senddoc, used by fax */
extern uchar options;			/* from main */
extern char *telno, *mercurypin;	/* from main */

extern "C"
  { double sin(double);
    int time(int*), fork();
    void execl(char* ...);
    int open(char*, uint, uint = 0);
    void close(int), atexit(proc), unlink(char*), sleep(int);
    char *strchr(char*, int);
    int strncmp(char*, char*, int);
    int select(int, uint*, uint*, uint*, int*);
    void *malloc(int), *realloc(void*, int);
    void free(void*);
  };

extern char *getpassword(char*);						/* from getpass.C  */
extern void dialnumber();							/* from dial.C	   */
extern void waitfortone(int);							/* from progress.C */
extern void becomemodem(int);							/* from modem.C	   */
extern void becomefax();							/* from fax.C	   */
extern void initdoc(), readdocpage(), senddocpage();				/* from doc.C	   */
extern void inittx(int), putaval(int), putsval(int), putbit(uint);		/* from txside.C   */
extern void sendpause(int), sendqam(int, complex, int);				/* from txside.C   */
extern void init_v29(), pbit_v29(uint);						/* from v29tx.C	   */
extern void initrx(int);							/* from rxside.C   */
extern int getaval(), getsval();						/* from rxside.C   */
extern void giveup(char* ...), infomsg(char* ...), writelog(char*, char* ...);	/* from common.C   */

