/* Modem for MIPS   AJF	  January 1995
   Modem routines */

#include <stdio.h>
#include <signal.h>
#include <sgtty.h>
#include <fishaudio.h>
#include "modem.h"

static void tty_ioctl(int, int, termios*);
static void rxloop(int), txloop(int);
static int nextchar();


global void becomemodem(int mode)
  { termios otmode, ntmode;
    tty_ioctl(1, TCGETA, &otmode);			    /* fetch current tty mode */
    ntmode = otmode;					    /* copy the struct	      */
    ntmode.c_iflag = ntmode.c_oflag = ntmode.c_lflag = 0;   /* set raw mode	      */
    ntmode.c_cc[VMIN] = ntmode.c_cc[VTIME] = 1;		    /* set timeout params     */
    tty_ioctl(2, TCSETAW, &ntmode);			    /* set new mode	      */
    setbuf(stdout, NULL);				    /* unbuffered stdout      */
    int cpid = fork();
    if (cpid < 0) giveup("fork failed");
    if (cpid == 0) rxloop(mode);			    /* child (never returns)  */
    txloop(mode);					    /* parent		      */
    kill(cpid, SIGUSR1);				    /* kill the child	      */
    tty_ioctl(3, TCSETAW, &otmode);			    /* reset tty mode	      */
  }

static void tty_ioctl(int n, int key, termios *p1)
  { int code = ioctl(0, key, p1); /* stdin */
    if (code < 0) giveup("tty ioctl failed (n=%d errno=%d)", n, errno);
  }

static void rxloop(int mode)
  { /* forked as a child */
    initrx(mode);
    for (;;)	/* until killed by parent */
      { int ch = getaval();	/* from 'phone line */
	putchar(ch);		/* to stdout */
      }
  }

static void txloop(int mode)
  { inittx(mode);
    int ch = nextchar();	/* from stdin */
    until (ch == 26)		/* ctl Z */
      { putaval(ch);		/* to 'phone line */
	ch = nextchar();
      }
  }

static int nextchar()
  { for (;;)
      { if (stdin -> _cnt > 0) return getchar();
	uint ib = 1; /* test stdin */
	int tmo[2] = { 0, 0 }; /* immediate return */
	int nb = select(32, &ib, NULL, NULL, tmo);
	if (nb > 0) return getchar();
	putbit(1);	/* send mark while idle */
      }
  }

