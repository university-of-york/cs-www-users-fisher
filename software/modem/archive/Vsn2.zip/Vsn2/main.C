/* Modem for MIPS   AJF	  January 1995
   Main program */

#include <stdio.h>
#include <signal.h>
#include <sys/fcntl.h>
#include <fishaudio.h>
#include "modem.h"

#define TOFN	   "/dev/ttyd2"
#define LOCKFN	   "/tmp/fishmodem.lock"  /* one lock file per Indy */

global audio tx_audio(AU_OUT), rx_audio(AU_IN);

global float sinetab[SINELEN];
global int contime, pagessent;
global ushort scanbits;		/* set by fax, used by senddoc */
global bool morepages;		/* set by senddoc, used by fax */
global uchar options;
global char *telno, *mercurypin;

static char *vmodes[] = { "-V21o", "-V21a", "-V23o", "-V23a", NULL };

struct pval { int code, nval, oval; };

pval pvals[] =
  { { AU_INPUT_RATE, AU_RATE_24000   },
    { AU_OUTPUT_RATE, AU_RATE_24000  },
    { AU_INPUT_SOURCE, AU_INPUT_LINE },
    { AU_LEFT_INPUT_ATTEN, 0	     },
    { AU_RIGHT_INPUT_ATTEN, 0	     },
    { AU_SPEAKER_MUTE_CTL, 1	     },
    { AU_MONITOR_CTL, 0		     },
    { -1, -1			     },
  };

static int mode;

static bool legaltelno(char*), legalpin(char*);
static void setoptions(char*[]);
static void usage(), sighandler(int), createlock(), destroylock(), openaudio(), closeaudio(), makesinetab(), seizeline();


global int main(int argc, char *argv[])
  { contime = -1; /* not connected yet */
    pagessent = 0;
    signal(SIGINT, (SIG_PF) sighandler); signal(SIGTERM, (SIG_PF) sighandler);
#ifdef ALARM
    signal(SIGALRM, (SIG_PF) sighandler);   /* safety alarm goes off after 10 mins */
#endif
    setoptions(argv);
    unless (legaltelno(telno)) giveup("Illegal telephone number");
    if (options & opt_m)
      { mercurypin = getpassword("Enter Mercury PIN: ");
	if (mercurypin == NULL) giveup("Error while reading PIN");
	unless (legalpin(mercurypin)) giveup("Illegal PIN");
      }
    createlock();
    if (options & opt_fax)
      { initdoc();
	unless (morepages) giveup("Empty document; not sent");
      }
    openaudio();
    makesinetab();
    seizeline();
    dialnumber();
    if (options & (opt_fax | opt_mod))
      { waitfortone(CONN_TONE); /* wait for answer (connect) tone */
	contime = time(NULL);
	infomsg("Connected");
	if (options & opt_fax) becomefax();
	if (options & opt_mod) becomemodem(mode);
	infomsg("Call duration: %d secs", time(NULL) - contime);
      }
    writelog("OK", "");
    return 0;
  }

static bool legaltelno(char *vec)
  { int n = 0;
    char *dstr = "0123456789*#ABCD";
    if (vec[n] == '+' || vec[n] == '=') n++;
    until (vec[n] == '\0' || strchr(dstr, vec[n]) == NULL) n++;
    return (n <= 16 && vec[n] == '\0');
  }

static bool legalpin(char *vec)
  { int n = 0;
    until (vec[n] == '\0' || !(vec[n] >= '0' && vec[n] <= '9')) n++;
    return (vec[n] == '\0' && (n == 10 || n == 12));
  }

static void setoptions(char *argv[])
  { int ap = 0;
    unless (argv[ap] == NULL) ap++;
    options = 0; telno = NULL;
    until (argv[ap] == NULL)
      { char *s = argv[ap++];
	if (s[0] == '+' || s[0] == '=')
	  { if (telno != NULL) usage();
	    telno = s;
	  }
	else if (seq(s, "-fax")) options |= opt_fax;
	else
	  { int k = 0;
	    unless (s[k++] == '-') usage();
	    if (s[k] == 'V')
	      { if (options & opt_mod) usage();
		mode = 0;
		until (vmodes[mode] == NULL || seq(vmodes[mode], s)) mode++;
		if (vmodes[mode] == NULL) usage();
		options |= opt_mod;
	      }
	    else
	      { until (s[k] == '\0')
		  { char ch = s[k++];
		    if (ch == 'v') options |= opt_v;
		    else if (ch == 'm') options |= opt_m;
		    else if (ch == 'p') options |= opt_p;
		    else usage();
		  }
	      }
	  }
      }
    if (telno == NULL) usage();
    if ((options & (opt_fax | opt_mod)) == (opt_fax | opt_mod)) usage();
  }

static void usage()
  { fprintf(stderr, "Modem V.2 from <fisher@minster.york.ac.uk>\n");
    fprintf(stderr, "Usage: modem [-[vmp]] [-<mode> | -fax] +<telnum>\n");
    fprintf(stderr, "Modes:");
    for (int i=0; vmodes[i] != NULL; i++) fprintf(stderr, " %s", vmodes[i]);
    putc('\n', stderr);
    exit(2);
  }

static void sighandler(int sig)
  { giveup("Signal %d!", sig);
  }

static void createlock()
  { int fd = open(LOCKFN, O_CREAT | O_EXCL, 0);
    if (fd < 0) giveup("Line is in use, please try again later"); /* lock file exists */
    close(fd);
    atexit(destroylock);
  }

static void destroylock()
  { unlink(LOCKFN);
  }

static void openaudio()
  { for (int i=0; pvals[i].code >= 0; i++)
      pvals[i].oval = tx_audio.control(pvals[i].code, pvals[i].nval);
    atexit(closeaudio);
  }

static void closeaudio()
  { tx_audio.flush();
    for (int i=0; pvals[i].code >= 0; i++)
      tx_audio.control(pvals[i].code, pvals[i].oval); /* restore */
  }

static void makesinetab()
  { for (int k=0; k < SINELEN; k++)
      { double th = TWOPI * (double) k / (double) SINELEN;
	sinetab[k] = sin(th);
      }
  }

static void seizeline()
  { sleep(2); /* wait in case line has only just been dropped */
    int fd = open(TOFN, O_RDWR); /* this asserts DTR */
    if (fd < 0) giveup("Can't open %s", TOFN);
  }

