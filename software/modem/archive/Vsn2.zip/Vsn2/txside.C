/* Modem for MIPS   AJF	  January 1995
   Transmit side : sync and async formatting & FSK output */

#include <fishaudio.h>
#include "modem.h"

#define SHAPELEN  10

#define V29_SCALE (0.31 * MAXAMPL)
#define FSK_SCALE (0.32 * MAXAMPL)

static complex czero = { 0.0, 0.0 };

typedef void (*pbp)(uint);	/* a "pbp" is a proc taking 1 uint arg */

struct fskinfo
  { ushort bd;		/* Tx baud rate	 */
    ushort f0, f1;	/* Tx tone freqs */
  };

static fskinfo fskinfo[] =
  { {  300, 1180,  980 },   /* V21o */
    {  300, 1850, 1650 },   /* V21a */
    {	75,  450,  390 },   /* V23o */
    { 1200, 2100, 1300 },   /* V23a */
  };

struct dpskinfo
  { proc init;		/* Tx init proc	      */
    pbp pbit;		/* put-a-bit proc     */
    float scale;	/* ampl. scale factor */
  };

static dpskinfo dpskinfo[] =
  { { init_v29,	 pbit_v29, V29_SCALE },	    /* V29 */
  };

static float shapetab[SHAPELEN+1] =
  { /* Raised cosine pulse shaping with Alpha = 0.5 (Shanmugam p. 195) */
    0.0000000000, 0.0464032383, 0.1212863347, 0.2252460502, 0.3543520014,
    0.5000000000, 0.6496453360, 0.7883611757, 0.9009842008, 0.9744680039,
    1.0000000000,
  };

static uint sineptr;
static uchar prevbits;
static ushort tone0, tone1, bdlen;
static complex prevampl;
static pbp pbproc;
static float scale;

static void putoctet(uchar), putbit_fsk(uint);
static void sendfreq(int, int);


global void inittx(int mode)
  { sineptr = prevbits = 0;
    prevampl = czero;
    unless (mode >= 0 && mode <= 4) giveup("Bug: Unimplemented Tx mode (%d)", mode);
    if (mode <= 3)
      { /* an FSK mode */
	tone0 = fskinfo[mode].f0;
	tone1 = fskinfo[mode].f1;
	scale = FSK_SCALE;
	bdlen = SAMPLERATE / fskinfo[mode].bd;	/* num. samples in one Bd */
	pbproc = putbit_fsk;
      }
    else
      { /* a DPSK mode */
	mode -= 4;
	scale = dpskinfo[mode].scale;
	pbproc = dpskinfo[mode].pbit;
	dpskinfo[mode].init();	/* call mode-specific init proc */
      }
  }

global void putaval(int n)   /* asynchronous output */
  { uint un = (n << 1) | 0x600; /* add start bit, 2 stop bits */
    until (un == 0) { putbit(un & 1); un >>= 1; }
  }

global void putsval(int x)   /* synchronous output */
  { if (x == HDLC_FLAG) putoctet(0x7e);
    else if (x == HDLC_ABORT) putoctet(0x7f);
    else
      { uchar n = x; int i;
	for (i=0; i < 8; i++)
	  { putbit(n >> 7);
	    if ((prevbits & 0x1f) == 0x1f) putbit(0); /* bit-stuffing */
	    n <<= 1;
	  }
      }
  }

static void putoctet(uchar n)
  { for (int i=0; i < 8; i++) { putbit(n >> 7); n <<= 1; }
  }

global void putbit(uint bit)
  { pbproc(bit);	/* dispatch */
  }

static void putbit_fsk(uint bit)
  { sendfreq(bit ? tone1 : tone0, bdlen);
    prevbits = (prevbits << 1) | bit;
  }

global void sendpause(int ns)
  { sendqam(0, czero, ns);	/* silence for "ns" samples */
  }

static void sendfreq(int f, int ns)
  { static complex ampl = { 3.0, 0.0 }; /* "standard" amplitude for fsk */
    sendqam(f, ampl, ns);
  }

#ifdef DEBUG
extern int debugnum;		/* from doc.C */
extern float debugbuf[];	/* from doc.C */
#endif

global void sendqam(int f, complex ampl, int ns)
  { int dph = (f * SINELEN) / SAMPLERATE;
    int n = 0;
    while (n < ns)
      { /* baseband pulse shaping */
	float te_shape = (n < SHAPELEN) ? shapetab[SHAPELEN-n] : 0.0;	  /* trailing-edge shape for previous pulse */
	float le_shape = (n < SHAPELEN) ? shapetab[n] : 1.0;		  /* leading-edge shape for new pulse	    */
	complex sh_ampl = (te_shape * prevampl) + (le_shape * ampl);
	/* modulate onto carrier */
	int ip = sineptr & (SINELEN-1);
	int qp = (sineptr + SINELEN/4) & (SINELEN-1);
	float val = scale * ((sh_ampl.re * sinetab[ip]) + (sh_ampl.im * sinetab[qp]));
#ifdef DEBUG
	if (debugnum >= 0 && (debugnum++ & 1) == 0) debugbuf[debugnum/2] = val;
#endif
	if (val > MAXAMPL || val < -MAXAMPL) giveup("Bug! out of range (sf): %08x", (int) val);
	tx_audio.write((int) val);
	sineptr += dph; n++;
      }
    prevampl = ampl;
  }

