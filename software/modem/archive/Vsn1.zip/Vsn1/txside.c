/* Modem for MIPS   AJF	  January 1995
   Transmit side : sync and async formatting & FSK output */

#include "modem.h"

#include <audio.h>

#define SHAPELEN  10

#define V29_SCALE (0.31 * MAXAMPL)
#define FSK_SCALE (0.32 * MAXAMPL)

extern struct audio *tx_audio;	/* from main */
extern float sinetab[];		/* from main */

static struct complex czero = { 0.0, 0.0 };

struct fskinfo
  { ushort bd;		/* Tx baud rate	 */
    ushort f0, f1;	/* Tx tone freqs */
  };

static struct fskinfo fskinfo[] =
  { {  300, 1180,  980 },   /* V21o */
    {  300, 1850, 1650 },   /* V21a */
    {	75,  450,  390 },   /* V23o */
    { 1200, 2100, 1300 },   /* V23a */
  };

struct dpskinfo
  { proc init;		/* Tx init proc	      */
    proc pbit;		/* put-a-bit proc     */
    float scale;	/* ampl. scale factor */
  };

forward putbit_fsk();

extern init_v29(), pbit_v29();

static struct dpskinfo dpskinfo[] =
  { { init_v29,	 pbit_v29, V29_SCALE },	    /* V29 */
  };

static float shapetab[SHAPELEN+1] =
  { /* Raised cosine pulse shaping with Alpha = 0.5 (Shanmugam p. 195) */
    0.0000000000, 0.0464032383, 0.1212863347, 0.2252460502, 0.3543520014,
    0.5000000000, 0.6496453360, 0.7883611757, 0.9009842008, 0.9744680039,
    1.0000000000,
  };

static uint sineptr;
static uchar prevbits;
static ushort tone0, tone1, bdlen;
static struct complex prevampl;
static proc pbproc;
static float scale;


global inittx(mode) int mode;
  { sineptr = 0;
    prevampl = czero;
    unless (mode >= 0 && mode <= 4) giveup("Bug: Unimplemented Tx mode (%d)", mode);
    if (mode <= 3)
      { /* an FSK mode */
	tone0 = fskinfo[mode].f0;
	tone1 = fskinfo[mode].f1;
	scale = FSK_SCALE;
	bdlen = SAMPLERATE / fskinfo[mode].bd;	/* num. samples in one Bd */
	pbproc = putbit_fsk;
      }
    else
      { /* a DPSK mode */
	mode -= 4;
	scale = dpskinfo[mode].scale;
	pbproc = dpskinfo[mode].pbit;
	dpskinfo[mode].init();	/* call mode-specific init proc */
      }
  }

global putaval(n) uint n;   /* asynchronous output */
  { n = (n << 1) | 0x600; /* add start bit, 2 stop bits */
    until (n == 0) { putbit(n & 1); n >>= 1; }
  }

global putsval(x) int x;    /* synchronous output */
  { if (x == HDLC_FLAG) putoctet(0x7e);
    else if (x == HDLC_ABORT) putoctet(0x7f);
    else
      { uchar n = x; int i;
	for (i=0; i < 8; i++)
	  { putbit(n >> 7);
	    if ((prevbits & 0x1f) == 0x1f) putbit(0); /* bit-stuffing */
	    n <<= 1;
	  }
      }
  }

static putoctet(n) uchar n;
  { int i;
    for (i=0; i < 8; i++) { putbit(n >> 7); n <<= 1; }
  }

global putbit(bit) uint bit;
  { pbproc(bit);	/* dispatch */
  }

static putbit_fsk(bit) uint bit;
  { sendfreq(bit ? tone1 : tone0, bdlen);
    prevbits = (prevbits << 1) | bit;
  }

global sendpause(ns) int ns;
  { sendqam(0, czero, ns);	/* silence for "ns" samples */
  }

global sendfreq(f, ns) int f, ns;	/* also called from progress */
  { static struct complex ampl = { 3.0, 0.0 }; /* "standard" amplitude for fsk etc */
    sendqam(f, ampl, ns);
  }

#ifdef DEBUG
extern int debugnum;
extern float debugbuf[];
#endif

global sendqam(f, ampl, ns) int f; struct complex ampl; int ns;
  { int dph, n;
    dph = (f * SINELEN) / SAMPLERATE;
    n = 0;
    while (n < ns)
      { struct complex sh_ampl; float te_shape, le_shape, val; int ip, qp;
	/* baseband pulse shaping */
	te_shape = (n < SHAPELEN) ? shapetab[SHAPELEN-n] : 0.0;	    /* trailing-edge shape for previous pulse */
	le_shape = (n < SHAPELEN) ? shapetab[n] : 1.0;		    /* leading-edge shape for new pulse	      */
	sh_ampl.re = (te_shape * prevampl.re) + (le_shape * ampl.re);
	sh_ampl.im = (te_shape * prevampl.im) + (le_shape * ampl.im);
	/* modulate onto carrier */
	ip = sineptr & (SINELEN-1);
	qp = (sineptr + SINELEN/4) & (SINELEN-1);
	val = scale * ((sh_ampl.re * sinetab[ip]) + (sh_ampl.im * sinetab[qp]));
#ifdef DEBUG
	if (debugnum >= 0 && (debugnum++ & 1) == 0) debugbuf[debugnum/2] = val;
#endif
	if (val > MAXAMPL || val < -MAXAMPL) giveup("Bug! out of range (sf): %08x", (int) val);
	if (NumFilled(tx_audio) >= RBLEN-2) WaitAudio(tx_audio, RBLEN/2); /* wait until half-full or less */
	WriteMono(tx_audio, (int) val);
	sineptr += dph;
	n++;
      }
    prevampl = ampl;
  }

