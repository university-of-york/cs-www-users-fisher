/* Modem for MIPS   AJF	  January 1995
   Modem routines */

#include "modem.h"

#include <audio.h>
#include <stdio.h>
#include <signal.h>
#include <sgtty.h>

extern struct audio *tx_audio;	/* from main */

extern int errno;

static struct termios otmode, ntmode;


global becomemodem(mode) int mode;
  { int cpid;
    tty_ioctl(1, TCGETA, &otmode);			    /* fetch current tty mode */
    ntmode = otmode;					    /* copy the struct	      */
    ntmode.c_iflag = ntmode.c_oflag = ntmode.c_lflag = 0;   /* set raw mode	      */
    ntmode.c_cc[VMIN] = ntmode.c_cc[VTIME] = 1;		    /* set timeout params     */
    tty_ioctl(2, TCSETAW, &ntmode);			    /* set new mode	      */
    setbuf(stdout, NULL);				    /* unbuffered stdout      */
    cpid = fork();
    if (cpid < 0) giveup("fork failed");
    if (cpid == 0) rxloop(mode);			    /* child (never returns)  */
    txloop(mode);					    /* parent		      */
    kill(cpid, SIGUSR1);				    /* kill the child	      */
    tty_ioctl(3, TCSETAW, &otmode);			    /* reset tty mode	      */
  }

static tty_ioctl(n, key, p1) int n, key; word p1;
  { int code = ioctl(0, key, p1); /* stdin */
    if (code < 0) giveup("tty ioctl failed (n=%d errno=%d)", n, errno);
  }

static rxloop(mode) int mode;
  { /* forked as a child */
    initrx(mode);
    for (;;)	/* until killed by parent */
      { int ch = getaval();	/* from 'phone line */
	putchar(ch);		/* to stdout */
      }
  }

static txloop(mode) int mode;
  { int ch;
    inittx(mode);
    ch = nextchar();		/* from stdin */
    until (ch == 26)		/* ctl Z */
      { putaval(ch);		/* to 'phone line */
	ch = nextchar();
      }
  }

static int nextchar()
  { for (;;)
      { uint ib; int nb; int tmo[2];
	if (stdin -> _cnt > 0) return getchar();
	ib = 1; /* test stdin */
	tmo[0] = tmo[1] = 0; /* immediate return */
	nb = select(32, &ib, NULL, NULL, tmo);
	if (nb > 0) return getchar();
	putbit(1);	/* send mark while idle */
      }
  }

