/* Modem for MIPS   AJF	  January 1995
   Wait for tone (dial, connect, etc.) */

#include "modem.h"

#include <audio.h>
/* #include <stdio.h> */

#define NPOLES	    4
#define MILLISEC    24

#define LPCOEFF	    1e-2	/* LP filter coefficient */
#define THRESH	    300.0	/* tone threshold (was 30.0) */

extern struct audio *tx_audio, *rx_audio;   /* from main */

/* Filter coeffs constructed by:
   mkfilter -Bu -Bp -o 2 -a (A1) (A2)
   where A1 = F1 / 24000, A2 = F2 / 24000
   Indexed by tone; see modem.h */

static float bpcoeffs[][NPOLES] =
  { { -0.9926225432, 3.9560628468, -5.9342967317, 3.9707369819 },     /*  390 ..  410 Hz, centre  400 Hz    [0]	       */
    { -0.9926225432, 3.9611665616, -5.9444736664, 3.9758596277 },     /*  340 ..  360 Hz, centre  350 Hz    [1] (dial) */
    { -0.9926225432, 3.8140448668, -5.6563716519, 3.8281922177 },     /* 1090 .. 1110 Hz, centre 1100 Hz    [2] (merc) */
    { -0.9926225431, 3.3916780429, -4.8898494759, 3.4042587182 },     /* 2090 .. 2110 Hz, centre 2100 Hz    [3] (conn) */
  };


global waitfortone(tone) int tone;
  { float xv[NPOLES+1], yv0[NPOLES+1], yv1[NPOLES+1];
    int count0_pres, count0_abs, count1, prescount, abscount, totcount, i; float p0, p1;
    inittx(0); /* arg is abrbitrary */
    if (tone == CONN_TONE) sendfreq(1100, SAMPLERATE/2); /* send CNG (0.5 sec, 1100 Hz) */
    count0_pres = count0_abs = count1 = prescount = abscount = totcount = 0;
    p0 = p1 = 0.0;
    for (i=0; i < NPOLES+1; i++) xv[i] = yv0[i] = yv1[i] = 0.0;
    for (;;)
      { WaitAudio(rx_audio, RBLEN/2); /* wait until half-full or more */
	while (NumFilled(rx_audio) > 0)
	  { shiftdown(xv, NPOLES);
	    xv[NPOLES] = (float) ReadMono(rx_audio);
	    totcount++;
	    switch (tone)
	      { case DIAL_TONE: case MERC_TONE:
		    if (totcount >= 5000*MILLISEC) giveup("No dial tone");
		    break;
		case CONN_TONE:
		    if (totcount >= 45000*MILLISEC) giveup("No reply"); /* long delay in case there's an answering m/c */
		    if (totcount % (3500*MILLISEC) == 0)
		      { /* re-play 0.5s CNG pulse */
			ReplayAudio(tx_audio, SAMPLERATE/2);
		      }
		    break;
	      }
	    filterstep(xv, yv0, bpcoeffs[0], &p0);
	    if (p0 >= THRESH)
	      { count0_pres++;
		if (count0_pres >= 2000*MILLISEC) giveup("Number unobtainable");
		if (count0_abs >= 300*MILLISEC && count0_abs <= 550*MILLISEC) abscount++;
		count0_abs = 0;
	      }
	    else
	      { count0_abs++;
		if (count0_pres >= 300*MILLISEC && count0_pres <= 550*MILLISEC) prescount++;
		count0_pres = 0;
	      }
	    if (prescount >= 4 && abscount >= 4) giveup("Number busy");
	    filterstep(xv, yv1, bpcoeffs[tone], &p1);
	    if (p1 >= THRESH)
	      { if (++count1 > 1000*MILLISEC) return; /* we've found what we were looking for */
	      }
	    else count1 = 0;
	    /* if ((totcount & 4095) == 0) fprintf(stderr, "%14.5e %14.5e\n", p0, p1); */
	  }
      }
  }

static filterstep(xv, yv, yco, pp) float xv[], yv[], yco[]; float *pp;
  { float w;
    shiftdown(yv, NPOLES);
    yv[4] = xv[0] + xv[4] - 2.0 * xv[2]
	  + (yco[0] * yv[0]) + (yco[1] * yv[1]) + (yco[2] * yv[2]) + (yco[3] * yv[3]);
    w = (yv[4] * yv[4]) * 1e-20;
    *pp += w - (LPCOEFF * *pp);
  }

