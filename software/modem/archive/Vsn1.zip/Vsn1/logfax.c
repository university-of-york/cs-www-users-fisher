#include "modem.h"
#include <stdio.h>

extern char *getenv(), *ctime(), *strpbrk();


global main(argc, argv) int argc; char *argv[];
  { FILE *fi; char fn[256], hn[33];
    int code, clock; char *un, *ctim;
    unless (argc == 2) usage();
    umask(022);
    code = gethostname(hn, 32); hn[32] = '\0';
    if (code != 0) giveup("gethostname failed!");
    if (strpbrk(hn, "./") != NULL) giveup("bad host name! %s", hn); /* hn mustn't contain '.' or '/' */
    un = getenv("LOGNAME");
    if (un == NULL) giveup("LOGNAME not set!");
    sprintf(fn, "/usr/fisher/faxlogs/%s", hn);
    fi = fopen(fn, "a");
    if (fi == NULL) giveup("can't append to log file");
    clock = time(NULL); ctim = ctime(&clock);
    ctim[24] = '\0'; /* delete nl */
    fprintf(fi, "%s %-8s %s\n", &ctim[4], un, argv[1]);
    fclose(fi);
    exit(0);
  }

static usage()
  { fprintf(stderr, "Usage: logfax 'msg'\n");
    exit(2);
  }

static giveup(msg, p1) char *msg, *p1;
  { fprintf(stderr, "logfax: ");
    fprintf(stderr, msg, p1); putc('\n', stderr);
    exit(1);
  }

