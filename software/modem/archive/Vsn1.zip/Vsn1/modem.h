#define global
#define forward
#define bool	    int
#define false	    0
#define true	    1
#define unless(x)   if(!(x))
#define until(x)    while(!(x))
#define seq(s1,s2)  (strcmp(s1,s2) == 0)

/* the following relies on memcpy's working with overlapping areas (which it does) */
#define shiftdown(v,n) memcpy(&v[0], &v[1], (n) * sizeof(float));

#define SAMPLERATE  24000
#define SINELEN	    32768	/* power of 2 */
#define PI	    3.14159265358979323846
#define TWOPI	    (2.0 * PI)
#define MAXAMPL	    (float) 0x3fffff	/* max amplitude for ADC, DAC (h/w accepts 0x7fffff) */

#define HDLC_FLAG   (-1)
#define HDLC_ABORT  (-2)

#define DIAL_TONE   1
#define MERC_TONE   2
#define CONN_TONE   3

#define NULL	    0

/* cmd line and other options */
#define opt_fax	    0x01    /* -fax : fax call	    */
#define opt_mod	    0x02    /* -V.. : modem call    */
#define opt_v	    0x04    /* -v : verbose	    */
#define opt_m	    0x08    /* -m : use Mercury 131 */
#define opt_p	    0x10    /* -p : private call    */
#define opt_H	    0x20    /* high resolution	    */

typedef unsigned char uchar;
typedef signed char schar;
typedef unsigned int uint;
typedef unsigned short ushort;
typedef int word;		/* or char* or ... */
typedef (*proc)();

struct complex { float re, im };

