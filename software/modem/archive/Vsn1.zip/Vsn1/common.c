/* Modem for MIPS   AJF	  January 1995
   Common routines */

#include "modem.h"

#include <stdio.h>

extern int contime, pagessent;		/* from main */
extern uchar options;			/* from main */
extern char *telno;			/* from main */


global giveup(msg, p1, p2, p3, p4) char *msg; word p1, p2, p3, p4;
  { writemsg("Error", msg, p1, p2, p3, p4);
    writelog("ER", msg, p1, p2, p3, p4);
    exit(1);
  }

global infomsg(msg, p1, p2, p3, p4) char *msg; word p1, p2, p3, p4;
  { writemsg("Info", msg, p1, p2, p3, p4);
  }

static writemsg(typ, msg, p1, p2, p3, p4) char *typ, *msg; word p1, p2, p3, p4;
  { fprintf(stderr, "*** %s: ", typ);
    fprintf(stderr, msg, p1, p2, p3, p4);
    putc('\n', stderr);
  }

global writelog(typ, msg, p1, p2, p3, p4) char *typ, *msg; word p1, p2, p3, p4;
  { char str[256]; int len, pid;
    sprintf(str, "%-16s ", telno);
    len = 17;
    str[len++] = (options & opt_mod) ? 'M' :	    /* modem mode, not fax		     */
		 (!(options & opt_fax)) ? 'V' :	    /* dial number only, presumed voice call */
		 (options & opt_H) ? 'H' : 'L';	    /* fax, high/low resolution		     */
    str[len++] = (options & opt_v) ? 'v' : ' ';
    str[len++] = (options & opt_m) ? 'm' : ' ';
    str[len++] = (options & opt_p) ? 'p' : ' ';
    do str[len++] = ' '; until (len >= 24);
    sprintf(&str[len], (contime >= 0) ? "%3ds " : "NC   ", time(NULL) - contime);        /* connect time */
    len += 5;
    sprintf(&str[len], "%2dp ", pagessent);
    len += 4;
    sprintf(&str[len], "%s ", typ);     /* OK or ER */
    len += (strlen(typ) + 1);
    sprintf(&str[len], msg, p1, p2, p3, p4);
    pid = fork(); /* ignore fork/exec errors */
    if (pid == 0)
      { execl("/usr/fisher/mipslib/logfax", "logfax", str, NULL);
	_exit(255);
      }
  }

