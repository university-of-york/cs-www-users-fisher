/* Modem for MIPS   AJF	  January 1995
   Receive side : sync and async formatting & FSK input */

#include "modem.h"

#include <audio.h>

#define NPOLES	4
#define BUFMASK 3

extern struct audio *rx_audio;	/* from main */

static uchar valid, framing, bitcount, bufhd, buftl;
static int syncbuf[4];
static ushort hbitlen;
static float lpcoeff, lpp0, lpp1;
static float xvals[NPOLES+1], yvals0[NPOLES+1], yvals1[NPOLES+1];
static float *yco0, *yco1;

/* Filter coeffs constructed by:
   mkfilter -Bu -Bp -o 2 -a (A1) (A2)
   where A1 = (F0 - Bd/2) / 24000, A2 = (F0 + Bd/2) / 24000 */

static float bpcoeffs[][NPOLES] =
  { { -0.9672274282, 3.8810890047, -5.8602627847, 3.9462973237 },     /*  345 ..  435 Hz, centre  390 Hz    [0] */
    { -0.9672274282, 3.8743642087, -5.8467815911, 3.9394595407 },     /*  405 ..  495 Hz, centre  450 Hz    [1] */
    { -0.8948743446, 3.5611124630, -5.4347481234, 3.7646386872 },     /*  830 .. 1130 Hz, centre  980 Hz    [2] */
    { -0.8948743446, 3.5073377192, -5.3284721717, 3.7077905862 },     /* 1030 .. 1330 Hz, centre 1180 Hz    [3] */
    { -0.6413515381, 2.7140236821, -4.4779393329, 3.3986058666 },     /*  700 .. 1900 Hz, centre 1300 Hz    [4] */
    { -0.8948743446, 3.3434382209, -5.0145298690, 3.5345238336 },     /* 1500 .. 1800 Hz, centre 1650 Hz    [5] */
    { -0.8948743446, 3.2581883313, -4.8571760711, 3.4444017059 },     /* 1700 .. 2000 Hz, centre 1850 Hz    [6] */
    { -0.6413515381, 2.4548946977, -3.9475276189, 3.0741144880 },     /* 1500 .. 2700 Hz, centre 2100 Hz    [7] */
  };

struct fskinfo
  { ushort bd;		  /* Rx baud rate			   */
    float *yco0, *yco1;	  /* bandpass filter coeffs for 0, 1 tones */
  };

static struct fskinfo fskinfo[] =
  { {  300, bpcoeffs[6], bpcoeffs[5] },	    /* V21o */
    {  300, bpcoeffs[3], bpcoeffs[2] },	    /* V21a */
    { 1200, bpcoeffs[7], bpcoeffs[4] },	    /* V23o */
    {	75, bpcoeffs[1], bpcoeffs[0] },	    /* V23a */
  };


global initrx(mode) int mode;
  { int i;
    unless (mode >= 0 && mode <= 3) giveup("Bug: Unimplemented Rx mode (%d)", mode);
    for (i=0; i < NPOLES+1; i++) xvals[i] = yvals0[i] = yvals1[i] = 0.0;
    yco0 = fskinfo[mode].yco0;
    yco1 = fskinfo[mode].yco1;
    hbitlen = SAMPLERATE / (2*fskinfo[mode].bd);  /* num. samples in half a bit */
    /* bit-rate LP filter f0 = (bitrate/2) */
    lpcoeff = 1.0 - (TWOPI * (double) fskinfo[mode].bd / (2.0 * SAMPLERATE)); /* bit-rate LP filter coefficient */
    lpp0 = lpp1 = 0.0;
    valid = bitcount = bufhd = buftl = 0;
    framing = 0x55;
    FlushAudio(rx_audio); /* empty Rx ring buffer */
  }

global int getaval()	/* asynchronous input */
  { bool bit; int i, j; uchar n;
    do bit = getsample(); while (bit);
    for (j=0; j < 3*hbitlen; j++) bit = getsample();
    for (i=0; i < 8; i++)
      { n = (n >> 1) | (bit << 7);
	for (j=0; j < 2*hbitlen; j++) bit = getsample();
      }
    return n;
  }

global int getsval()	/* synchronous input */
  { static uchar thebits, thechar;
    while (bufhd == buftl)
      { int j; bool bit;
	if (valid & 0x80)
	  { thechar = (thechar << 1) | (thebits >> 7);
	    if (++bitcount == 8)
	      { insert(thechar);
		bitcount = 0;
	      }
	  }
	j = 0;
	while (j < 2*hbitlen)
	  { bit = getsample();
	    framing = (framing << 1) | bit;
	    if (framing == 0xf0 || framing == 0x0f) j = hbitlen+4; else j++;
	  }
	thebits = (thebits << 1) | bit;
	valid = (valid << 1) | 1;
	switch (thebits)
	  { case 0x7c:	case 0x7d:
		valid &= ~2;	/* delete bit-stuffing */
		break;

	    case 0x7e:
		insert(HDLC_FLAG);
		valid = bitcount = 0;
		break;

	    case 0x7f:
		insert(HDLC_ABORT);
		valid = bitcount = 0;
		break;
	  }
      }
    return remove();
  }

static insert(x) int x;
  { syncbuf[buftl] = x;
    buftl = (buftl+1) & BUFMASK;
  }

static int remove()
  { int x = syncbuf[bufhd];
    bufhd = (bufhd+1) & BUFMASK;
    return x;
  }

static bool getsample()
  { if (NumFilled(rx_audio) == 0) WaitAudio(rx_audio, RBLEN/2); /* wait until half-full or more */
    shiftdown(xvals, NPOLES);
    xvals[NPOLES] = (float) ReadMono(rx_audio);
    filterstep(xvals, yvals0, yco0, &lpp0);
    filterstep(xvals, yvals1, yco1, &lpp1);
    return (lpp1 >= lpp0);
  }

static filterstep(xv, yv, yco, pp) float xv[], yv[], yco[]; float *pp;
  { shiftdown(yv, NPOLES);
    yv[4] = xv[0] + xv[4] - 2.0 * xv[2]
	  + (yco[0] * yv[0]) + (yco[1] * yv[1]) + (yco[2] * yv[2]) + (yco[3] * yv[3]);
    *pp = (lpcoeff * *pp) + (yv[4] * yv[4]);
  }

