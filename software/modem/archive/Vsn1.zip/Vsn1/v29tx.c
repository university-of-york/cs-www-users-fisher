/* Modem for MIPS   AJF	  January 1995
   V.29 transmit routines */

#include "modem.h"

#include <audio.h>
#include <stdio.h>

/* tables for DPSK encoding */
static uchar phinctab[8] = { 1, 6, 2, 5, 0, 7, 3, 4 };

static struct complex constellation[16] =
  { { +3.0, 0.0 }, { +1.0, +1.0 }, { 0.0, +3.0 }, { -1.0, +1.0 },	/*  0 -	 3 */
    { -3.0, 0.0 }, { -1.0, -1.0 }, { 0.0, -3.0 }, { +1.0, -1.0 },	/*  4 -	 7 */
    { +5.0, 0.0 }, { +3.0, +3.0 }, { 0.0, +5.0 }, { -3.0, +3.0 },	/*  8 - 11 */
    { -5.0, 0.0 }, { -3.0, -3.0 }, { 0.0, -5.0 }, { +3.0, -3.0 },	/* 12 - 15 */
  };

static struct complex czero = { 0.0, 0.0 };

static uint scrambler;
static uchar sigelement, bitcount;


global init_v29()
  { int i; uchar reg;
    /* Segment 1 */
    sendqam(0, czero, 480);		    /* silence */
    /* Segment 2 */
    for (i=0; i < 128; i++)
      { sigelement = (i & 1) ? 7 : 4;	    /* A or B */
	sendbaud();
      }
    /* Segment 3 */
    reg = 0x2a;
    for (i=0; i < 384; i++)
      { uint b6 = (reg >> 1) & 1;
	uint b7 = reg & 1;
	sigelement = b7 ? 3 : 0;	    /* C or D */
	sendbaud();
	reg >>= 1;
	if (b6 ^ b7) reg |= 0x40;
      }
    /* Segment 4 */
    scrambler = bitcount = 0;
    for (i=0; i < 144; i++) pbit_v29(1);    /* scrambled 1s */
  }

global pbit_v29(bit) uint bit;		    /* V.29 bit output (7200 bit/s) */
  { uint b18 = (scrambler >> 5) & 1;
    uint b23 = scrambler & 1;
    bit = bit ^ b18 ^ b23;
    scrambler >>= 1;
    if (bit) scrambler |= 0x400000;
    if (++bitcount == 3)
      { uchar x = scrambler >> 20;			/* delta phase from most recent 3 bits */
	sigelement = (sigelement + phinctab[x]) & 7;
	sendbaud();
	bitcount = 0;
      }
  }

static sendbaud()
  { sendqam(1700, constellation[sigelement], 10);
  }

